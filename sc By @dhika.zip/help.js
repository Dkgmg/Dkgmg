
// disini atur aja kak menu bot nya
// jangan lupa hapus fitur yg ga penting

var monoSpace = '```'

exports.listmenu = (sender,prefix,ad,namenya,premnya,usernya,romnya,tanggal,jam,no) => {
return`──「 *List-menu* 」────

╔╣ *INFO USER* ╠
║ ID : ${namenya}
║ Nama : @${sender.split('@')[0]}
║ Premium : ${premnya}
╚════════════

╔╣  *INFO BOT* ╠
║ Library : Symplebot-Md
║ Time : ${jam} WIB
║ Date : ${tanggal}
║ Terdaftar : ${usernya}
║ Room Chat : ${romnya}
║ Server: ẉGusion.id
╚════════════

══   ══   ══   ══  ͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏ ══


 ✘ *INFO MENU*
  ❒ ${prefix}menu
  ❒ ${prefix}iklan
  ❒ ${prefix}rules
  ❒ ${prefix}owner
  ❒ ${prefix}script
  ❒ ${prefix}infobot
  ❒ ${prefix}donasi
  ❒ ${prefix}donate
  ❒ ${prefix}jadibot
  ❒ ${prefix}listjadibot
  ❒ ${prefix}sewabot
  ❒ ${prefix}groupbot
  ❒ ${prefix}ownerinfo
  ❒ ${prefix}infoowner

 ✘ *USER MENU*
  ❒ ${prefix}verify
  ❒ ${prefix}report
  ❒ ${prefix}request
  ❒ ${prefix}transfer
  ❒ ${prefix}menfess
  ❒ ${prefix}buatroom
  ❒ ${prefix}secretchat
  ❒ ${prefix}cekprem
  ❒ ${prefix}daftarprem
  ❒ ${prefix}changename

 ✘ *OWNER MENU*
  ❒ ${prefix}resetdb
  ❒ ${prefix}runtime
  ❒ ${prefix}setexif
  ❒ ${prefix}setwm
  ❒ ${prefix}setfooter
  ❒ ${prefix}setppbot
  ❒ ${prefix}addprem
  ❒ ${prefix}delprem
  ❒ ${prefix}bc
  ❒ ${prefix}bctext
  ❒ ${prefix}bcvideo
  ❒ ${prefix}bcaudio
  ❒ ${prefix}bcimage
  ❒ ${prefix}broadcast

 ✘ *Mtk MENU*
  ❒ ${prefix}kali 1 2
  ❒ ${prefix}bagi 1 2
  ❒ ${prefix}kurang 1 2
  ❒ ${prefix}tambah 1 2
  
 ✘ *GRUP MENU*
  ❒ ${prefix}fitnah
  ❒ ${prefix}delete
  ❒ ${prefix}revoke
  ❒ ${prefix}tagall
  ❒ ${prefix}hidetag
  ❒ ${prefix}setdesc
  ❒ ${prefix}linkgrup
  ❒ ${prefix}infogroup
  ❒ ${prefix}setppgrup
  ❒ ${prefix}setnamegrup
  ❒ ${prefix}group open
  ❒ ${prefix}group close
  ❒ ${prefix}antilink on
  ❒ ${prefix}antilink off
  ❒ ${prefix}welcome on
  ❒ ${prefix}welcome off
  ❒ ${prefix}tiktokauto on
  ❒ ${prefix}tiktokauto off
  ❒ ${prefix}kick @tag
  ❒ ${prefix}demote @tag
  ❒ ${prefix}promote @tag
 
 ✘ *WEB MENU*
  ❒ ${prefix}sadcat
  ❒ ${prefix}translate
  ❒ ${prefix}stalkff
  ❒ ${prefix}stalknpm
  ❒ ${prefix}stalkgithub
  ❒ ${prefix}balikhuruf
  ❒ ${prefix}balikangka
  ❒ ${prefix}besarkecil
  ❒ ${prefix}bilangangka

 ✘ *DOWNLOAD MENU*
  ❒ ${prefix}tiktok
  ❒ ${prefix}ytmp3
  ❒ ${prefix}ytmp4
  ❒ ${prefix}gitclone
  ❒ ${prefix}mediafire
  ❒ ${prefix}wikimedia
  ❒ ${prefix}soundcloud
  ❒ ${prefix}infogempa

 ✘ *CONVERTER MENU*
  ❒ ${prefix}attp
  ❒ ${prefix}toimg
  ❒ ${prefix}toimage
  ❒ ${prefix}tomp3
  ❒ ${prefix}toaudio
  ❒ ${prefix}tomp4
  ❒ ${prefix}tovideo
  ❒ ${prefix}emojimix
  ❒ ${prefix}emojmix
  ❒ ${prefix}emojinua
  ❒ ${prefix}mixemoji
  ❒ ${prefix}stiker
  ❒ ${prefix}sticker
  ❒ ${prefix}sgif
  ❒ ${prefix}stikergif
  ❒ ${prefix}stickergif
  ❒ ${prefix}swm
  ❒ ${prefix}stikerwm
  ❒ ${prefix}stickerwm
  ❒ ${prefix}smeme
  ❒ ${prefix}memestiker
  ❒ ${prefix}stikermeme
  ❒ ${prefix}stickermeme
  ❒ ${prefix}emojinua
  ❒ ${prefix}mixemoji
  ❒ ${prefix}emojmix
  ❒ ${prefix}emojimix

 ✘ *LAIN MENU*
  ❒ ${prefix}spamcall
  ❒ ${prefix}translate
  ❒ ${prefix}ssweb-pc
  ❒ ${prefix}ssweb-hp
  ❒ ${prefix}bitly_short
  ❒ ${prefix}cuttly_short
  ❒ ${prefix}tinyurl_short
  ❒ ${prefix}base32
  ❒ ${prefix}base64
  ❒ ${prefix}debase32
  ❒ ${prefix}debase64

 ✘ *BUG MENU*
  ❒ ${prefix}sendbug 628xxx
  ❒ ${prefix}philips 628xxx
  ❒ ${prefix}philips2 628xxx
  ❒ ${prefix}philips3 628xxx
  ❒ ${prefix}santet @tag
  ❒ ${prefix}santet2 @tag
  ❒ ${prefix}santet3 @tag
  ❒ ${prefix}virtex 628xxx
  ❒ ${prefix}virtex2 628xxx
  ❒ ${prefix}virtex3 628xxx
  ❒ ${prefix}bug1 628xxx
  ❒ ${prefix}bug2 628xxx
  ❒ ${prefix}bug3 628xxx
  ❒ ${prefix}bug4 628xxx
  ❒ ${prefix}bug5 628xxx
 
 ✘ *ANONYMOUS MENU*
  ❒ ${prefix}buatroom 628xxx
  ❒ ${prefix}room <only owner>
  ❒ ${prefix}stopchat <only room>
  ❒ ${prefix}menfess 628xx|bot|hai
 
 ✘ *HAHIHU MENU*
  ❒ ${prefix}hilih <text>
  ❒ ${prefix}halah <text>
  ❒ ${prefix}huluh <text>
  ❒ ${prefix}heleh <text>
  ❒ ${prefix}holoh <text>
 
 ✘ *ASUPAN MENU*
  ❒ ${prefix}rika
  ❒ ${prefix}bocil
  ❒ ${prefix}ukhty
  ❒ ${prefix}santuy
  ❒ ${prefix}hijaber

 ✘ *NEWS MENU*
  ❒ ${prefix}gempa
  ❒ ${prefix}jadwaltv
  ❒ ${prefix}gempanow
  ❒ ${prefix}bioskopnow

 ✘ *RANDOM FOTO* 
  ❒ ${prefix}milf
  ❒ ${prefix}loli
  ❒ ${prefix}waifu
  ❒ ${prefix}husbu
  ❒ ${prefix}cosplay
  ❒ ${prefix}ppcouple
  ❒ ${prefix}cecan
  ❒ ${prefix}cogan
  ❒ ${prefix}mobil
  ❒ ${prefix}darkjokes
  ❒ ${prefix}boneka

 ✘ *PREMIUM MENU*
  ❒ ${prefix}cry
  ❒ ${prefix}hug
  ❒ ${prefix}pat
  ❒ ${prefix}bully
  ❒ ${prefix}lick
  ❒ ${prefix}kiss
  ❒ ${prefix}awoo
  ❒ ${prefix}waifu
  ❒ ${prefix}shinobu
  ❒ ${prefix}cuddle
  ❒ ${prefix}megumin
  ❒ ${prefix}slap
  ❒ ${prefix}neko
  ❒ ${prefix}wink
  ❒ ${prefix}dance
  ❒ ${prefix}poke
  ❒ ${prefix}glomp
  ❒ ${prefix}bite
  ❒ ${prefix}nom
  ❒ ${prefix}handhold
  ❒ ${prefix}highfive
  ❒ ${prefix}wave
  ❒ ${prefix}smug
  ❒ ${prefix}smile
  ❒ ${prefix}bonk

 ✘ *SOUND MENU*
  ❒ ${prefix}sound1
  ❒ ${prefix}sound2
  ❒ ${prefix}sound3
  ❒ ${prefix}sound4
  ❒ ${prefix}sound5
  ❒ ${prefix}sound6
  ❒ ${prefix}sound7
  ❒ ${prefix}sound8
  ❒ ${prefix}sound9
  ❒ ${prefix}sound10
  ❒ ${prefix}sound11
  ❒ ${prefix}sound12
  ❒ ${prefix}sound13
  ❒ ${prefix}sound14
  ❒ ${prefix}sound15
  ❒ ${prefix}sound16
  ❒ ${prefix}sound17
  ❒ ${prefix}sound18
  ❒ ${prefix}sound19
  ❒ ${prefix}sound20
  ❒ ${prefix}sound21
  ❒ ${prefix}sound22
  ❒ ${prefix}sound23
  ❒ ${prefix}sound24
  ❒ ${prefix}sound25
  ❒ ${prefix}sound26
  ❒ ${prefix}sound27
  ❒ ${prefix}sound28
  ❒ ${prefix}sound29
  ❒ ${prefix}sound30
  ❒ ${prefix}sound31
  ❒ ${prefix}sound32
  ❒ ${prefix}sound33
  ❒ ${prefix}sound34
  ❒ ${prefix}sound35
  ❒ ${prefix}sound36
  ❒ ${prefix}sound37
  ❒ ${prefix}sound38
  ❒ ${prefix}sound39
  ❒ ${prefix}sound40
  ❒ ${prefix}sound41
  ❒ ${prefix}sound42
  ❒ ${prefix}sound43
  ❒ ${prefix}sound44
  ❒ ${prefix}sound45
  ❒ ${prefix}sound46
  ❒ ${prefix}sound47
  ❒ ${prefix}sound48
  ❒ ${prefix}sound49
  ❒ ${prefix}sound50
  ❒ ${prefix}sound51
  ❒ ${prefix}sound52
  ❒ ${prefix}sound53
  ❒ ${prefix}sound54
  ❒ ${prefix}sound55
  ❒ ${prefix}sound56
  ❒ ${prefix}sound57
  ❒ ${prefix}sound58
  ❒ ${prefix}sound59
  ❒ ${prefix}sound60
  ❒ ${prefix}sound61
  ❒ ${prefix}sound62
  ❒ ${prefix}sound63
  ❒ ${prefix}sound64
  ❒ ${prefix}sound65
  ❒ ${prefix}sound66
  ❒ ${prefix}sound67
  ❒ ${prefix}sound68
  ❒ ${prefix}sound69
  ❒ ${prefix}sound70
  ❒ ${prefix}sound71
  ❒ ${prefix}sound72
  ❒ ${prefix}sound73
  ❒ ${prefix}sound74

 ✘ *LOGO MENU*
  ❒ ${prefix}metallic text
  ❒ ${prefix}naruto text
  ❒ ${prefix}butterfly text
  
  
  *Note:*
  gunain fitur yg tersedia di menu jangan yg aneh-aneh
 `
}

exports.rulesBot = () =>{
return`*──「 RULES-BOT 」──*

1. Jangan spam bot. 
Sanksi: *WARN/SOFT BLOCK*

2. Jangan telepon bot.
Sanksi: *SOFT BLOCK*

3. Jangan mengejek bot.
Sanksi: *PERMANENT BLOCK*

Jika sudah paham rulesnya
Ketik *#menu* untuk memulai bot`
}

exports.donasiBot = (cekName,sender,ucapanWaktu) =>{
return`──「 *MENU DONATE* 」──

Hi *${sender.split('@')[0]}* ${ucapanWaktu} 👋🏻

*Payment Pulsa*
Number: 085649212256 (indosat)
A/N: DHIKA

*Payment Dana*
Number: 085850185698
A/N: DHIKA

${monoSpace}Terimakasih untuk kamu yang sudah donasi untuk perkembangan bot ini ^_^${monoSpace}

──「 *THX FOR YOU* 」──`
}

exports.infoOwner = () =>{
return`──「 *INFO OWNER* 」──

 *Data Profil*
 • *Nama:* Dhika
 • *Umur:* 14 tahun
 • *Hoby:* Turu/Game
 • *Askot:* Lamongan
 • *Konten:* Creator

_iam developer bot whatsapp._

 *Sosial Media*
 • *Whatsapp:* 085649212256
 • *Youtube:* Devi|slebew
 • *Github:* GAk ada
 `
}